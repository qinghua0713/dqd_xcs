<template>
  <div class="right-content" v-if="$store.state.num == 2">

  </div>
</template>

<script>

export default {
  name: "ACS",
  data() {
    return {};
  },

};
</script>

<style scoped>
</style>